﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ModExtractor
{
    public partial class FrmProcess : Form
    {
        Timer timer;
        string ModedGameRoot, OrginalGameRoot, DestinationModRoot;
        
        private FrmProcess()
        {
            InitializeComponent();
        }

        public FrmProcess(string modedGameRoot, string orginalGameRoot, string destinationModRoot):this()
        {
            ModedGameRoot = modedGameRoot;
            OrginalGameRoot = orginalGameRoot;
            DestinationModRoot = destinationModRoot;
        }

        private void FrmProcess_Load(object sender, EventArgs e)
        {
            timer = new Timer();

        }

        private void Process()
        {
            try
            {
                #region Ctor

                string ModedGameRoot = TbModedGame.Text;
                string OrginalGameRoot = TbOrginalGame.Text;
                string DestinationModRoot = TbDestinationMod.Text;

                if (ModedGameRoot[ModedGameRoot.Length - 1] != '\\')
                    ModedGameRoot += "\"";

                if (OrginalGameRoot[OrginalGameRoot.Length - 1] != '\\')
                    OrginalGameRoot += "\"";

                if (DestinationModRoot[DestinationModRoot.Length - 1] != '\\')
                    DestinationModRoot += "\"";

                string _FILES_DIR = Path.Combine(DestinationModRoot, Program._FILES_DIR);
                string _UnKnw_DIR = Path.Combine(DestinationModRoot, Program._UnKnw_DIR);
                string _DELETED_FILE = Path.Combine(DestinationModRoot, Program._DELETED_FILE);
                #endregion

                #region chk folders and files

                if (!Directory.Exists(ModedGameRoot))
                    throw new DirectoryNotFoundException($"'{ModedGameRoot}' not found");

                if (!Directory.Exists(OrginalGameRoot))
                    throw new DirectoryNotFoundException($"'{OrginalGameRoot}' not found");

                if (!Directory.Exists(DestinationModRoot))
                    Directory.CreateDirectory(DestinationModRoot);
                if (!Directory.Exists(_FILES_DIR))
                    Directory.CreateDirectory(_FILES_DIR);
                if (!Directory.Exists(_UnKnw_DIR))
                    Directory.CreateDirectory(_UnKnw_DIR);
                if (File.Exists(_DELETED_FILE))
                    File.Delete(_DELETED_FILE);
                File.Create(_DELETED_FILE).Close();

                #endregion

                #region Def       

                List<string> ModedGameFiles = new List<string>();
                ModedGameFiles.AddRange(Directory.GetFiles(ModedGameRoot, "*.*", SearchOption.AllDirectories));

                List<string> DeletedOrginalGameFiles = new List<string>();
                DeletedOrginalGameFiles.AddRange(Directory.GetFiles(OrginalGameRoot, "*.*", SearchOption.AllDirectories));

                List<string> ModFiles = new List<string>();
                List<string> UnknownFiles = new List<string>();
                List<string> DeletedFiles = new List<string>();

                #endregion

                #region Compair

                foreach (string ModFile in ModedGameFiles)
                {
                    string GameFile = ModFile.Replace(ModedGameRoot, OrginalGameRoot);

                    if (File.Exists(GameFile))
                    {
                        DeletedOrginalGameFiles.Remove(GameFile);

                        var ModFI = new FileInfo(ModFile);
                        var GameFI = new FileInfo(GameFile);

                        if (ModFI.Length == GameFI.Length)
                            if (ModFI.LastWriteTimeUtc == GameFI.LastWriteTimeUtc)
                                continue;//its a Orginal Game File
                            else
                            {
                                UnknownFiles.Add(ModFile);
                                continue;
                            }
                    }

                    ModFiles.Add(ModFile);
                }

                DeletedOrginalGameFiles.ForEach(file => { DeletedFiles.Add(file.Replace(OrginalGameRoot, "")); });

                #endregion

                #region MoveModFiles

                ModFiles.ForEach(file =>
                {
                    string fileDist = file.Replace(ModedGameRoot, _FILES_DIR);
                    if (!Directory.Exists(Path.GetDirectoryName(fileDist)))
                        Directory.CreateDirectory(fileDist);
                    File.Move(file, fileDist);
                });

                UnknownFiles.ForEach(file =>
                {
                    string fileDist = file.Replace(ModedGameRoot, _UnKnw_DIR);
                    if (!Directory.Exists(Path.GetDirectoryName(fileDist)))
                        Directory.CreateDirectory(fileDist);
                    File.Move(file, fileDist);
                });

                using (StreamWriter sw = File.AppendText(_DELETED_FILE))
                    DeletedOrginalGameFiles.ForEach(file => { sw.WriteLine(file); });

                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }
    }
}
